﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WxPayAPI;

namespace MVC_WxPay_Demo.Controllers
{
    public class WxPayController : Controller
    {
        /// <summary>
        /// 调用js获取收货地址时需要传入的参数
        /// 格式：json串
        /// 包含以下字段：
        /// appid：公众号id
        /// scope: 填写“jsapi_address”，获得编辑地址权限
        /// signType:签名方式，目前仅支持SHA1
        /// addrSign: 签名，由appid、url、timestamp、noncestr、accesstoken参与签名
        /// timeStamp：时间戳
        /// nonceStr: 随机字符串
        /// </summary>
        public static string wxEditAddrParam { get; set; }
        /// <summary>
        /// openId
        /// </summary>
        public static string openid { get; set; }
        /// <summary>
        /// 授权后微信端返回的code（用于获取openid和access_token）
        /// </summary>
        public static string code { get; set; }
        /// <summary>
        /// H5调起JS API参数
        /// </summary>
        public static string wxJsApiParam { get; set; }
        [AllowAnonymous]
        public ActionResult Index()
        {
            #region 此处微信会回调传code去获取openid和access_token,可以自己封装
            JsApiPay jsApiPay = new JsApiPay(HttpContext);
            jsApiPay.GetOpenidAndAccessToken();
            if (jsApiPay.openid != null)
            {
                openid = jsApiPay.openid;
                GetJsApiParameters();
            }
            #endregion
            ViewBag.Params = wxJsApiParam;
            return View();
        }

        /// <summary>
        /// 获取前端参数
        /// </summary>
        private void GetJsApiParameters()
        {
            if (openid != null)
            {
                //若传递了相关参数，则调统一下单接口，获得后续相关接口的入口参数
                JsApiPay jsApiPay = new JsApiPay(HttpContext);
                jsApiPay.openid = openid;
                jsApiPay.total_fee = 1; //1分钱
                jsApiPay.attach = "test";
                jsApiPay.goods_tag = "test";
                jsApiPay.body = "body";
                //jsapi支付预处理
                try
                {
                    WxPayData unifiedorderresult = jsApiPay.GetUnifiedOrderResult();
                    wxJsApiParam = jsApiPay.GetJsApiParameters();//获取h5调起js api参数
                }
                catch (Exception ex)
                {
                }
            }
        }

        /// <summary>
        /// 回调
        /// </summary>
        public void Notify()
        {
            //任意发挥
        }
    }
}